install all dependencies andrun gulp to start

    >npm install
    >gulp

server will be working on port 3000
